# Ryan:
Shopping cart, items in
https://stackoverflow.com/questions/8189800/django-store-user-image-in-model
            <script>
                alert('{{error}}')
            </script>



# Chris:




# Jim:
[]Products Page with inventory count.
[]    Quantity sold.
[]    action (edit/delete)
[]    product ID
[]    picture
[]    add products page
[]    update views and html to reflect the models page




<!--------------------------------------------------------------------------------------------------------------------------------------------------->

To do:
image within a model?
profile_image = ImageField(upload_to=get_image_path, blank=True, null=True)

[x] Templates--------
[x]Login and Reg:
[x]    validations
[x]    Login
[x]    Register
[]    
[]Admin:
[x]    login (separate url)
[x]    dashboard
[x]    dashboard orders
[]        Orders needs to be a model?!
[]        (search by each field click ID should go to order)
[x]        Status dropdown for shipped/in process/cancelled
[]        Filter table showing by (All, shipped, processed, cancelled)
[]
[x]    dashboard products
[x]    dashboard show
[x]    dashboard edit product
[]
[]Dojo Categories page:
[]    Shopping cart, items in
[]    types of category names (plust total items)
[]        sidebar
[]        templatefilter (total|length)
[]        show all
[]    dropdown: sort by price/most popular
[]    jump to page.
[]    populate by item.
[]    searchbar---------- integration??
[]
[]
[]
[]
[]ShowItem page:
[]    go back button (to category)
[]    Shopping cart, items in
[x]    logout accross from go back.
[]
[]
[]
[xXx]## Pagination? django templates. google that.
[]
[]## item quantity and shopping cart logic.
[]
[]
[]Category page:
[]    Shopping cart reflects
[]
[]
[]Products Page with inventory count.
[]    Quantity sold.
[]    action (edit/delete)
[]    product ID
[]    picture
[]    add products page
[]
[]New product page:
[]    dropdown menu within the classes we have.
[]
[]
[]Edit Product page?:
[]# basics instead of below
[]    
[naw]    AJAX??
[]    auto generate from current product.
[]    change category
[]    maybe add a new category?

New 2Do--------------------------------------------------------
[]pip install django-shopping-cart
[]categorypage.
[]make the categories show under total products
[]use shell to delete the current products.
[]shopping cart show actual number
[]add to cart button to work
[]about this product
[]put error messages above on registration page
[]Need to be able to change password for admin after first login to create a hashed password.
[]admin products need edit and delete function
[]copy pagination
[]update images
